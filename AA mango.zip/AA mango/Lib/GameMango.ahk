#Requires AutoHotkey v2.0

global macroStartTime := A_TickCount
global stageStartTime := A_TickCount
global contractPageCounter := 0
global contractSwitchPattern := 0
global BossRoomCompleted := false
global SaveChestsForBoss := true

;HotKeys
Hotkey(F1Key, (*) => moveRobloxWindow())
Hotkey(F2Key, (*) => StartMacro())
Hotkey(F3Key, (*) => Reload())
Hotkey(F4Key, (*) => TogglePause())

PlacingUnits() {
    global successfulCoordinates
    successfulCoordinates := []
    placedCounts := Map()

    anyEnabled := false
    for slotNum in [1, 2, 3, 4, 5, 6] {
        enabled := "enabled" slotNum
        enabled := %enabled%
        enabled := enabled.Value
        if (enabled) {
            anyEnabled := true
            break
        }
    }

    if (!anyEnabled) {
        ProcessLog("No Units Selected - Returning")
        return MonitorStage()
    }

    placementPoints := PlacementPatternDropdown.Text = "Circle" ? GenerateCirclePoints() :
        PlacementPatternDropdown.Text = "Grid" ? GenerateGridPoints() :
        GenerateRandomPoints()

    ; Go through each slot
    for slotNum in [1, 2, 3, 4, 5, 6] {
        enabled := "enabled" slotNum
        enabled := %enabled%
        enabled := enabled.Value

        ; Get number of placements wanted for this slot
        placements := "placement" slotNum
        placements := %placements%
        placements := Integer(placements.Text)

        ; Initialize count if not exists
        if !placedCounts.Has(slotNum)
            placedCounts[slotNum] := 0

        ; If enabled, place all units for this slot
        if (enabled && placements > 0) {
            ProcessLog("Placing Unit: " slotNum " (0/" placements ")")

            ; Place all units for this slot
            while (placedCounts[slotNum] < placements) {
                for point in placementPoints {
                    ; Skip if this coordinate was already used successfully
                    alreadyUsed := false
                    for coord in successfulCoordinates {
                        if (coord.x = point.x && coord.y = point.y) {
                            alreadyUsed := true
                            break
                        }
                    }
                    if (alreadyUsed)
                        continue

                    if PlaceUnit(point.x, point.y, slotNum) {
                        successfulCoordinates.Push({ x: point.x, y: point.y, slot: slotNum })
                        placedCounts[slotNum] += 1
                        ProcessLog("Placed Unit: " slotNum " (" placedCounts[slotNum] "/" placements ")")
                        Sleep(500)
                        FixClick(560, 560) ; Move Click
                        break
                    }

                    Wave40Reached()

                    if CheckForXp()
                        return MonitorStage()
                    Reconnect()
                    CheckEndAndRoute()
                }
                Sleep(500)
            }
        }
    }

    ProcessLog("Placed all Units")
    UpgradeUnits()
}

UpgradeUnits() {
    global successfulCoordinates, PriorityUpgrade, priority1, priority2, priority3, priority4, priority5, priority6

    totalUnits := Map()
    upgradedCount := Map()

    ; Initialize counters
    for coord in successfulCoordinates {
        if (!totalUnits.Has(coord.slot)) {
            totalUnits[coord.slot] := 0
            upgradedCount[coord.slot] := 0
        }
        totalUnits[coord.slot]++
    }

    ProcessLog("Process to upgrading...")

    if (PriorityUpgrade.Value) {
        ProcessLog("Using priority system")

        ; Go through each priority level (1-6)
        for priorityNum in [1, 2, 3, 4, 5, 6] {
            ; Find which slot has this priority number
            for slot in [1, 2, 3, 4, 5, 6] {
                priority := "priority" slot
                priority := %priority%
                if (priority.Text = priorityNum) {
                    ; Skip if no units in this slot
                    hasUnitsInSlot := false
                    for coord in successfulCoordinates {
                        if (coord.slot = slot) {
                            hasUnitsInSlot := true
                            break
                        }
                    }

                    if (!hasUnitsInSlot) {
                        continue
                    }
                    ProcessLog("Priority upgrade for: " priorityNum " (slot " slot ")")

                    ; Keep upgrading current slot until all its units are maxed
                    while true {
                        slotDone := true

                        for index, coord in successfulCoordinates {
                            if (coord.slot = slot) {
                                slotDone := false
                                UpgradeUnit(coord.x, coord.y)

                                if CheckForXp() {
                                    ProcessLog("Stage ended during upgrades, proceeding to results")
                                    successfulCoordinates := []
                                    MonitorStage()
                                    return
                                }

                                if MaxUpgrade() {
                                    upgradedCount[coord.slot]++
                                    ProcessLog("Maxed out for: " coord.slot " (" upgradedCount[coord.slot] "/" totalUnits[coord.slot] ")")
                                    successfulCoordinates.RemoveAt(index)
                                    CheckAbility()
                                    FixClick(325, 185) ;Close upg menu
                                    break
                                }

                                Sleep(200)
                                CheckAbility()
                                MahogoraAbility()
                                FixClick(560, 560) ; move click

                                ; click mahogora ability when upgrading
                                FixClick(239, 420)
                                FixClick(298, 420)
                                FixClick(358, 420)

                                Reconnect()
                                CheckEndAndRoute()
                                Wave40Reached()
                            }
                        }

                        if (slotDone || successfulCoordinates.Length = 0) {
                            ProcessLog("Upgrade Priority maxed for: " priorityNum)
                            break
                        }
                    }
                }
            }
        }
        ProcessLog("Priority Upgrade successfully")
        return MonitorStage()
    } else {
        ; Normal upgrade (no priority)
        while true {
            if (successfulCoordinates.Length == 0) {
                ProcessLog("All units maxed out, waiting for end stage...")
                return MonitorStage()
            }

            for index, coord in successfulCoordinates {
                UpgradeUnit(coord.x, coord.y)

                if CheckForXp() {
                    ProcessLog("Stage ended, replay...")
                    successfulCoordinates := []
                    MonitorStage()
                    return
                }

                if MaxUpgrade() {
                    upgradedCount[coord.slot]++
                    ProcessLog("Maxed out for: " coord.slot " (" upgradedCount[coord.slot] "/" totalUnits[coord.slot] ")")
                    successfulCoordinates.RemoveAt(index)
                    FixClick(325, 185) ;Close upg menu
                    continue
                }

                Sleep(200)
                CheckAbility()
                MahogoraAbility()
                FixClick(560, 560) ; Move Click
                Reconnect()
                FixClick(560, 560)
                Wave40Reached()
                CheckEndAndRoute()
            }
        }
    }
}

StoryMode() {
    global StoryDropdown, StoryActDropdown

    ; Get current map and act
    currentStoryMap := StoryDropdown.Text
    currentStoryAct := StoryActDropdown.Text

    ; Execute the movement pattern
    ProcessLog("Moving to: " currentStoryMap)
    StoryMovement()

    ; Start stage
    while !(ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        StoryMovement()
    }
    ProcessLog("Starting: " currentStoryMap " - " currentStoryAct)
    StartStory(currentStoryMap, currentStoryAct)

    ; Handle play mode selection
    if (StoryActDropdown.Text != "Infinity") {
        PlayHere()  ; Always PlayHere for normal story acts
    } else {
        if (MatchMaking.Value) {
            FindMatch()
        } else {
            PlayHere()
        }
    }
    RestartStage()
}

PortalMode() {
    global PortalDropdown
    ;get portal type
    currentPortalType := PortalDropdown.Text
    ; Execute the movement pattern
    while !(ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        PortalMovement()
    }
    ProcessLog("Going to: - " currentPortalType)
    ; Handle play mode selection
    RestartStage()
}

FarmMode() {
    ProcessLog("Processing for Farm Mode")
    while !(ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        FarmMovement()
    }
    ProcessLog("Going to Farm")
    PlayHere()
    RestartStage()
}

InfQuestMode() {
    ProcessLog("Processing for Daily Infinite Quest")
    while !(ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        InfQuestMovement()
    }
    if (MatchMaking.Value) { ;find match or play alone
        FindMatch()
    } else {
        PlayHere()
    }
    ProcessLog("Entering Inf quest...")
    RestartStage()
}

LegendMode() {
    global LegendDropdown, LegendActDropdown

    ; Get current map and act
    currentLegendMap := LegendDropdown.Text
    currentLegendAct := LegendActDropdown.Text

    ; Execute the movement pattern
    ProcessLog("Moving to: " currentLegendMap)
    StoryMovement()

    ; Start stage
    while !(ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        StoryMovement()
    }
    ProcessLog("Processing: " currentLegendMap " - " currentLegendAct)
    StartLegend(currentLegendMap, currentLegendAct)

    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    RestartStage()
}

RaidMode() {
    global RaidDropdown, RaidActDropdown

    ; Get current map and act
    currentRaidMap := RaidDropdown.Text
    currentRaidAct := RaidActDropdown.Text

    ; Execute the movement pattern
    ProcessLog("Moving to: " currentRaidMap)
    RaidMovement()

    ; Start stage
    while !(ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        RaidMovement()
    }
    ProcessLog("Processing: " currentRaidMap " - " currentRaidAct)
    StartRaid(currentRaidMap, currentRaidAct)
    ; Handle play mode selection
    if (MatchMaking.Value) {
        FindMatch()
    } else {
        PlayHere()
    }

    RestartStage()
}

InfinityCastleMode() {
    global InfinityCastleDropdown

    ; Get current difficulty
    currentDifficulty := InfinityCastleDropdown.Text

    ; Execute the movement pattern
    ProcessLog("Di chuyển tới vô hạn thành")
    InfCastleMovement()

    ; Start stage
    while !(ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        InfCastleMovement()
    }
    ProcessLog("Bắt đầu vô hạn thành - " currentDifficulty)

    ; Select difficulty with direct clicks
    if (currentDifficulty = "Normal") {
        FixClick(418, 375)  ; Click Easy Mode
    } else {
        FixClick(485, 375)  ; Click Hard Mode
    }

    ;Start Inf Castle
    if (ok := FindText(&X, &Y, 325, 520, 489, 587, 0, 0, ModeCancel)) {
        ClickUntilGone(0, 0, 325, 520, 489, 587, ModeCancel, -10, -120)
    }

    RestartStage()
}

ContractMode() {
    Sleep(10000)
    if (ContractJoinDropdown.Text = "Creating") {
        FixClick(35, 400)  ; Click contracts
        Sleep(1000)
        HandleContractJoin()
    } else if (ContractJoinDropdown.Text = "Matchmaking") {
        FixClick(35, 400)  ; Click contracts
        Sleep(1000)
        HandleContractJoin()
    } else {
        ProcessLog("Joined portal")
    }
    Sleep(2500)
    RestartStage()
}

DungeonMode() {
    ProcessLog("Entering Dungeon Mode")
    FixClick(85, 400)  ; Click Dungeon mode button
    Sleep(1000)
    if (ok := FindText(&X, &Y, 310, 395, 495, 440, 0.20, 0.20, EnterDungeon)) {
        FixClick(395, 380)
    }
    Sleep(1000)
    ; Select dungeon route and enter
    SelectDungeonRoute()
}

ClickReplay() {
    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, +120, -35, LobbyText2)
}

ClickNextLevel() {
    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, +260, -35, LobbyText2)
}

ClickReturnToLobby() {
    ClickUntilGone(0, 0, 80, 85, 739, 224, LobbyText, 0, -35, LobbyText2)
}

MonitorEndScreen() {
    global mode, StoryDropdown, StoryActDropdown, ReturnLobbyBox, MatchMaking

    Loop {
        Sleep(3000)

        FixClick(560, 560)

        if (ok := FindText(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
        }

        if (ok := FindText(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
            ClickUntilGone(0, 0, 260, 400, 390, 450, NextText, 0, -40)
        }

        ; Now handle each mode
        if (ok := FindText(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or (ok := FindText(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
            ProcessLog("Tìm thấy Lobby - Chế độ hiện tại: " mode)
            if (mode = "Story") {
                ProcessLog("Handling Story end")
                if (StoryActDropdown.Text != "Infinity") {
                    if (NextLevelBox.Value && lastResult = "win") {
                        ProcessLog("Next match")
                        ClickNextLevel()
                    } else {
                        ProcessLog("Replay")
                        ClickReplay()
                    }
                } else {
                    ProcessLog("Story Infinity Return")
                    ClickReturnToLobby()
                    return CheckLobby()
                }
                return RestartStage()
            }
            else if (mode = "Portal") {
                ProcessLog("Handling Portal end")
                if (ReturnLobbyBox.Value) {
                    ProcessLog("Return Lobby")
                    ClickReturnToLobby()
                    return CheckLobby()
                }
            }
            else if (mode = "Daily Infinite Quest") {
                if (ReturnLobbyBox.Value) {
                    ProcessLog("Return Lobby")
                    ClickReturnToLobby()
                    return CheckLobby()
                }
            }
            else if (mode = "Farm") {
                ProcessLog ("Handling Farm end")
                ProcessLog("Replay")
                ClickReplay()
                return RestartStage()
            }
            else if (mode = "Raid") {
                ProcessLog("Handling Raid end")
                if (ReturnLobbyBox.Value) {
                    ProcessLog("Return Lobby")
                    ClickReturnToLobby()
                    return CheckLobby()
                } else {
                    ProcessLog("Replay Raid")
                    ClickReplay()
                    return RestartStage()
                }
            }
            else if (mode = "Infinity Castle") {
                ProcessLog("Handling Infinite Castle")
                if (lastResult = "win") {
                    ProcessLog("Next Match")
                    ClickReplay()
                } else {
                    ProcessLog("Replay")
                    ClickReplay()
                }
                return RestartStage()
            } else if (mode = "Daily Infinite Quest") {
                ProcessLog("Handling Daily Quest end")
                ClickReturnToLobby()
                return CheckLobby()
            } else {
                ProcessLog("Handling after lose")
                if (ReturnLobbyBox.Value) {
                    ProcessLog("Return Lobby")
                    ClickReturnToLobby()
                    return CheckLobby()
                } else {
                    ProcessLog("Replay")
                    ClickReplay()
                    return RestartStage()
                }
            }
        }
        Reconnect()
    }
}

MonitorStage() {
    global Wins, loss, mode, StoryActDropdown

    lastClickTime := A_TickCount

    Loop {
        Sleep(1000)

        if ((mode = "Story" && StoryActDropdown.Text = "Infinity") || (mode = "Farm") || (mode = "Daily Infinite Quest")) {
            timeElapsed := A_TickCount - lastClickTime
            if (timeElapsed >= 300000) {  ; 5 minutes
                ProcessLog("Processing for Anti-AFK...")
                FixClick(560, 560) ; Move click

                ;mahogora ability checker
                FixClick(239, 400)
                FixClick(298, 400)
                FixClick(358, 400)

                MahogoraAbility()
                if (FindText(&x, &y, 0, 0, A_ScreenWidth, A_ScreenHeight, 0, 0, Wave40Inf)) {
                    Wave40Reached()
                }

                lastClickTime := A_TickCount
            }
        }

        ; Check for XP screen
        if CheckForXp() {
            ProcessLog("Checking win/loss status...")

            ; Calculate stage end time here, before checking win/loss
            stageEndTime := A_TickCount
            stageLength := FormatStageTime(stageEndTime - stageStartTime)

            if (ok := FindText(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
                ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
            }

            ; Check for Victory or Defeat
            if (ok := FindText(&X, &Y, 150, 180, 350, 260, 0, 0, VictoryText) or (ok := FindText(&X, &Y, 150, 180, 350, 260, 0, 0, VictoryText2))) { ;if win
                ProcessLog("Victory detected - Stage Length: " stageLength)
                Wins += 1
                SendWebhookWithTime(true, stageLength)
                if (mode = "Contract") {
                    return HandleContractEnd()  ; New function for Contract endings
                } else if (mode = "Dungeon") {
                    return MonitorDungeonEnd()  ; New function for Dungeon endings
                } else {
                    return MonitorEndScreen()  ; Original behavior for other modes
                }
            } else if (ok := FindText(&X, &Y, 150, 180, 350, 260, 0, 0, DefeatText) or (ok := FindText(&X, &Y, 150, 180, 350, 260, 0, 0, DefeatText2))) { ;if loss
                ProcessLog("Defeat detected - Stage Length: " stageLength)
                loss += 1
                SendWebhookWithTime(false, stageLength)
                if (mode = "Contract") {
                    return HandleContractEnd()  ; New function for Contract endings
                } else if (mode = "Dungeon") {
                    return MonitorDungeonEnd()  ; New function for Dungeon endings
                } else if (mode = "Daily Infinite Quest") {
                    return Wave40Reached() ; new function for daily endings
                } else {
                    return MonitorEndScreen()  ; Original behavior for other modes
                } 
            }
        }
        Reconnect()
    }
}

StoryMovement() {
    FixClick(85, 295) ;click Play
    sleep (1000)
    ;move to game choose
    SendInput ("{w down}")
    Sleep(300)
    SendInput ("{w up}")
    Sleep(300)
    SendInput ("{d down}")
    SendInput ("{w down}")
    Sleep(4500)
    SendInput ("{d up}")
    SendInput ("{w up}")
    Sleep(500)
}

;go to Walled City for worthy farm
FarmMovement() {
    FixClick(85, 295) ;click Play
    sleep (1000)
    ;move to game choose
    SendInput ("{w down}")
    Sleep(300)
    SendInput ("{w up}")
    Sleep(300)
    SendInput ("{d down}")
    SendInput ("{w down}")
    Sleep(4500)
    SendInput ("{d up}")
    SendInput ("{w up}")
    Sleep(500)
    FixClick(640, 70)
    ;enter nav mode
    SendInput("{LShift down}\{LShift up}")
    Sleep(500)
    ;select farm mode
    loop 3 {
        SendInput("{s}")
        Sleep(500)
    }
    ;choose farm mode
    SendInput("{Enter}")
    Sleep(500)
    ;exit nav mode
    SendInput("{LShift down}\{LShift up}")
    Sleep(500)
}

Wave40Reached() {
    if (FindText(&x, &y, 186, 97, 256, 124, 0, 0, Wave40Inf)) {
        ProcessLog("Wave 40 has rearched")
        FixClick(26, 570) ;click settings
        Sleep 300
        FixClick(400, 215)
        Sleep(300)
    }
    if (ok := FindText(&X, &Y, 215, 160, 596, 480, 0, 0, Spawn)) {
        ProcessLog("Đã tìm thấy Teleport to Lobby")
        FixClick(X + 100, Y + 50)
        return CheckLobby()
    } else {
        ProcessLog("Không thể tìm thấy Teleport to Lobby")
    }
    Sleep 300
    FixClick(583, 147)
    Sleep 300
}

PortalSearch() { ; try to search portal in items bags
    DemonsPlaceColor := 0xFF60FF
    ShibuyaColor := 0x86FEFF

    ProcessLog("Searching for Portal...")
    Sleep(500)
    FixClick(40, 310) ;click Items
    Sleep(1500)
    FixClick(446, 225) ;click Portals Page
    Sleep(1500)
    ;scroll down to find portal
    MouseMove(442, 415, 10)
    if (PortalDropdown.Text = "Shibuya District") {
        while !((FindText(&x, &y, 171, 237, 634, 485, 0, 0, ShibuyaPortal)) && (PixelSearch(&foundX, &foundY, 171, 237, 634, 485, ShibuyaColor, 0))) {
            Sleep(1500)
            loop {
                Send ("{WheelDown}")
                if (FindText(&x, &y, 171, 237, 634, 485, 0, 0, ShibuyaPortal)) && (PixelSearch(&foundX, &foundY, 171, 237, 634, 485, ShibuyaColor, 0)) {
                    break
                }
                Sleep(2000)
            }
        }
        FixClick(x, y)
        Sleep(1500)
    } else if (PortalDropdown.Text = "Demons Leader Place") {
        while !((FindText(&x, &y, 171, 237, 634, 485, 0, 0, DemonsPlacePortal)) && (PixelSearch(&x, &y, 171, 237, 634, 485, DemonsPlaceColor, 0))) {
            Sleep(1500)
            loop {
                Send ("{WheelDown}")
                if (FindText(&x, &y, 171, 237, 634, 485, 0, 0, DemonsPlacePortal)) && (PixelSearch(&x, &y, 171, 237, 634, 485, DemonsPlaceColor, 0)) {
                    break
                }
                Sleep(2000)
            }
            Sleep(1500)
        }
        FixClick(x, y)
        Sleep(500)
    }
    Sleep(1500)
}

PortalMovement() {
    PortalSearch() 
    if (ok := FindText(&x2, &y2, 181, 362, 634, 475, 0, 0, Use_Portal)) {
        FixClick(x2, y2 - 40)
        Sleep(1000)
        FixClick(312, 350)
        Sleep(1000)
        FixClick(404, 482)
        Sleep(1000)
        ProcessLog("Opened a Portal, joining in...")
    }
    Sleep(1000)
}

FoundMapType() { ; just use for infinite daily quest mode
    global TextColor := 0xFCCF00
    if (FindText(&X1, &Y1, 214, 191, 587, 512, 0, 0, SandInf)) {
        return 5
    } else if (FindText(&X1, &Y1, 214, 191, 587, 512, 0, 0, FiendInf)) {
        return 7
    } else if (FindText(&X1, &Y1, 214, 191, 587, 512, 0, 0, AntKingdomInf)) {
        return 9
    } else if (FindText(&X1, &Y1, 214, 191, 587, 512, 0, 0, MagicTownInf)) {
        return 10
    } else if (FindText(&X1, &Y1, 214, 191, 587, 512, 0, 0, PuppetInf)) {
        return 17
    } else if (FindText(&X1, &Y1, 214, 191, 587, 512, 0, 0, DungeonThroneInf)) {
        return 20
    } else if (FindText(&X1, &Y1, 214, 191, 587, 512, 0, 0, ShibuyaInf)) {
        return 23
    } else {
        return 0 ; Không tìm thấy map
    }
}

EnterNavMode(steps) {
    SendInput("{LShift down}\{LShift up}") ; enable nav key
    loop steps {
        SendInput("{Down}")
        Sleep (500)
    }
    Sleep(500)
    SendInput("{Enter}")
    Sleep(500)
    SendInput("{LShift down}\{LShift up}") ; disable nav key
}

InfQuestMovement() {
    FixClick(640, 70) ; close player board
    Sleep(500)

    FixClick(770, 280) ; open quest
    Sleep(500)
    FixClick(453, 157) ; choose inf quest
    Sleep(500)

    if (FindText(&x, &y, 216, 190, 587, 516, 0, 0, ClaimText)) { ; claim reward
        loop 5 {
            FixClick(x, y-30)
            Sleep(500)
        }
    }
    Sleep(1000)

    mapSteps := 0 

    loop  i := 1 {
        found := FoundMapType()
        if (found > 0) {
            mapSteps := found 
        }
        Sleep(200)
        i++
    }

    if (mapSteps > 0) {
        FixClick(600, 130) ;close quest
        ProcessLog("Found map, attempt to quest")
        StoryMovement()
        EnterNavMode(mapSteps)
    } else {
        ProcessLog("No map detected, moving to Farm")
        return FarmMode()
    }

    Sleep(500)
}

RaidMovement() {
    FixClick(765, 475) ; Click Area
    Sleep(300)
    FixClick(495, 410)
    Sleep(500)
    SendInput ("{a down}")
    Sleep(400)
    SendInput ("{a up}")
    Sleep(500)
    SendInput ("{w down}")
    Sleep(5000)
    SendInput ("{w up}")
}

InfCastleMovement() {
    FixClick(765, 475) ;click Area
    Sleep (300)
    FixClick(370, 330)
    Sleep (500)
    SendInput ("{w down}")
    Sleep (500)
    SendInput ("{w up}")
    Sleep (500)
    SendInput ("{a down}")
    sleep (4000)
    SendInput ("{a up}")
    Sleep (500)
}

StartStory(map, StoryActDropdown) {
    FixClick(640, 70) ; Closes Player leaderboard
    Sleep(500)
    navKeys := GetNavKeys()
    for key in navKeys {
        SendInput("{" key "}")
    }
    Sleep(500)

    downArrows := GetStoryDownArrows(map) ; Map selection down arrows in GUI

    Loop downArrows { ;send time depend on map position
        SendInput("{Down}")
        Sleep(200)
    }

    SendInput("{Enter}") ; Select storymode
    Sleep(500)

    Loop 4 {
        SendInput("{Up}") ; Makes sure it selects act
        Sleep(200)
    }

    SendInput("{Left}") ; Go to act selection
    Sleep(1000)

    actArrows := GetStoryActDownArrows(StoryActDropdown) ; Act selection down arrows

    Loop actArrows {
        SendInput("{Down}")
        Sleep(200)
    }

    SendInput("{Enter}") ; Select Act
    Sleep(500)
    for key in navKeys {
        SendInput("{" key "}")
    }
}

StartLegend(map, LegendActDropdown) {
    FixClick(640, 70) ; Closes Player leaderboard
    Sleep(500)
    navKeys := GetNavKeys()
    for key in navKeys {
        SendInput("{" key "}")
    }
    Sleep(500)
    SendInput("{Down}")
    Sleep(500)
    SendInput("{Enter}") ; Opens Legend Stage

    downArrows := GetLegendDownArrows(map) ; Map selection down arrows
    Loop downArrows {
        SendInput("{Down}")
        Sleep(200)
    }

    SendInput("{Enter}") ; Select LegendStage
    Sleep(500)

    Loop 4 {
        SendInput("{Up}") ; Makes sure it selects act
        Sleep(200)
    }

    SendInput("{Left}") ; Go to act selection
    Sleep(1000)

    actArrows := GetLegendActDownArrows(LegendActDropdown) ; Act selection down arrows
    Loop actArrows {
        SendInput("{Down}")
        Sleep(200)
    }

    SendInput("{Enter}") ; Select Act
    Sleep(500)
    for key in navKeys {
        SendInput("{" key "}")
    }
}

StartRaid(map, RaidActDropdown) {
    FixClick(640, 70) ; Closes Player leaderboard
    Sleep(500)
    navKeys := GetNavKeys()
    for key in navKeys {
        SendInput("{" key "}")
    }
    Sleep(500)

    downArrows := GetRaidDownArrows(map) ; Map selection down arrows
    Loop downArrows {
        SendInput("{Down}")
        Sleep(200)
    }

    SendInput("{Enter}") ; Select Raid

    Loop 4 {
        SendInput("{Up}") ; Makes sure it selects act
        Sleep(200)
    }

    SendInput("{Left}") ; Go to act selection
    Sleep(500)

    actArrows := GetRaidActDownArrows(RaidActDropdown) ; Act selection down arrows
    Loop actArrows {
        SendInput("{Down}")
        Sleep(200)
    }

    SendInput("{Enter}") ; Select Act
    Sleep(300)
    for key in navKeys {
        SendInput("{" key "}")
    }
}

PlayHere() {
    FixClick(400, 435)  ; Play Here or Find Match
    Sleep (300)
    FixClick(330, 325) ;Click Play here
    Sleep (300)
    FixClick(400, 465) ;
    Sleep (300)
}

FindMatch() {
    startTime := A_TickCount

    Loop {
        if (A_TickCount - startTime > 50000) {
            ProcessLog("Matchmaking timeout, restarting mode")
            FixClick(400, 520)
            return StartSelectedMode()
        }

        FixClick(400, 435)  ; Play Here or Find Match
        Sleep(300)
        FixClick(460, 330)  ; Click Find Match
        Sleep(300)

        ; Try captcha
        if (!CaptchaDetect(252, 292, 300, 50, 400, 335)) {
            ProcessLog("Không thấy Capcha, đang thử lại...")
            FixClick(585, 190)  ; Click close
            Sleep(1000)
            continue
        }
        FixClick(300, 385)  ; Enter captcha
        return true
    }
}

GetStoryDownArrows(map) {
    switch map {
        case "Planet Greenie": return 2
        case "Walled City": return 3
        case "Snowy Town": return 4
        case "Sand Village": return 5
        case "Navy Bay": return 6
        case "Fiend City": return 7
        case "Spirit World": return 8
        case "Ant Kingdom": return 9
        case "Magic Town": return 10
        case "Haunted Academy": return 11
        case "Magic Hills": return 12
        case "Space Center": return 13
        case "Alien Spaceship": return 14
        case "Fabled Kingdom": return 15
        case "Ruined City": return 16
        case "Puppet Island": return 17
        case "Virtual Dungeon": return 18
        case "Snowy Kingdom": return 19
        case "Dungeon Throne": return 20
        case "Mountain Temple": return 21
        case "Rain Village": return 22
        case "Shibuya District": return 23
    }
}

GetStoryActDownArrows(StoryActDropdown) {
    switch StoryActDropdown {
        case "Infinity": return 1
        case "Act 1": return 2
        case "Act 2": return 3
        case "Act 3": return 4
        case "Act 4": return 5
        case "Act 5": return 6
        case "Act 6": return 7
    }
}

GetPortalDownType(PortalDropdown) {
    switch PortalDropdown {
        case "Shibuya": return 23
        case "Pupet": return 17
        case "Demons Place": return 15
    }
}


GetLegendDownArrows(map) {
    switch map {
        case "Magic Hills": return 1
        case "Space Center": return 3
        case "Fabled Kingdom": return 4
        case "Virtual Dungeon": return 6
        case "Dungeon Throne": return 7
        case "Rain Village": return 8
    }
}

GetLegendActDownArrows(LegendActDropdown) {
    switch LegendActDropdown {
        case "Act 1": return 1
        case "Act 2": return 2
        case "Act 3": return 3
    }
}

GetRaidDownArrows(map) {
    switch map {
        case "Sacred Planet": return 2
        case "Strange Town": return 3
        case "Ruined City": return 4
    }
}

GetRaidActDownArrows(RaidActDropdown) {
    switch RaidActDropdown {
        case "Act 1": return 1
        case "Act 2": return 2
        case "Act 3": return 3
        case "Act 4": return 4
        case "Act 5": return 5
    }
}

Zoom() {
    MouseMove(400, 300)
    Sleep 100

    ; Zoom in smoothly
    Loop 10 {
        Send "{WheelUp}"
        Sleep 50
    }

    ; Look down
    Click
    MouseMove(400, 400)  ; Move mouse down to angle camera down

    ; Zoom back out smoothly
    Loop 20 {
        Send "{WheelDown}"
        Sleep 50
    }

    ; Move mouse back to center
    MouseMove(400, 300)
}

TpSpawn() {
    FixClick(26, 570) ;click settings
    Sleep 300
    FixClick(400, 215)
    Sleep 300
    loop 4 {
        Sleep 150
        SendInput("{WheelDown 1}") ;scroll
    }
    Sleep 300
    if (ok := FindText(&X, &Y, 215, 160, 596, 480, 0, 0, Spawn)) {
        ProcessLog("Đã tìm thấy Teleport to Spawn")
        FixClick(X + 100, Y - 30)
    } else {
        ProcessLog("Không thể tìm thấy Teleport to Spawn")
    }
    Sleep 300
    FixClick(583, 147)
    Sleep 300
}

CloseChat() {
    if (ok := FindText(&X, &Y, 123, 50, 156, 79, 0, 0, OpenChat)) {
        ProcessLog ("Đã đóng chat")
        FixClick(138, 30) ;close chat
    }
}

BasicSetup() {
    SendInput("{Tab}") ; Closes Player leaderboard
    Sleep 300
    FixClick(564, 72) ; Closes Player leaderboard
    Sleep 300
    CloseChat()
    Sleep 300
    Zoom()
    Sleep 300
    TpSpawn()
}

DetectMap() {
    ProcessLog("Tiến hành di chuyển vào map...")
    startTime := A_TickCount

    Loop {
        ; Check if we waited more than 5 minute for votestart
        if (A_TickCount - startTime > 300000) {
            if (ok := FindText(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
                ProcessLog("Đang ở Lobby - trở lại chế độ đã chọn")
                return StartSelectedMode()
            }
            ProcessLog("Không thể tìm được map sau 5 phút - Tiến hành xử lý không thông qua movement")
            return "no map found"
        }

        ; Check for vote screen
        if (ok := FindText(&X, &Y, 326, 60, 547, 173, 0, 0, VoteStart) or (ok := FindText(&X, &Y, 340, 537, 468, 557, 0, 0, Yen))) {
            ProcessLog("Không tìm được map")
            return "no map found"
        }

        mapPatterns := Map(
            "Planet Greenie", Greenie,
            "Ant Kingdom", Ant,
            "Magic Town", MagicTown,
            "Magic Hill", MagicHills,
            "Navy Bay", Navy,
            "Snowy Town", SnowyTown,
            "Fiend City", Fiend,
            "Spirit World", Spirit,
            "Haunted Academy", Academy,
            "Space Center", SpaceCenter,
            "Mountain Temple", Mount,
            "Cursed Festival", Cursed,
            "Nightmare Train", Nightmare,
            "Air Craft", AirCraft,
            "Hellish City", Hellish,
            "Shibuya District", Shibuya
        )

        for mapName, pattern in mapPatterns {
            if (ok := FindText(&X, &Y, 10, 90, 415, 160, 0, 0, pattern)) {
                ProcessLog("Đã tìm thấy map: " mapName)
                return mapName
            }
        }

        Sleep 1000
        Reconnect()
    }
}

HandleMapMovement(MapName) {
    ProcessLog("Tiến hành di chuyển tới: " MapName)

    switch MapName {
        case "Planet Greenie":
            MoveForGreenie()
        case "Snowy Town":
            MoveForSnowyTown()
        case "Ant Kingdom":
            MoveForAntKingdom()
        case "Magic Town":
            MoveForMagicTown()
        case "Magic Hill":
            MoveForMagicHill()
        case "Navy Bay":
            MoveForNavyBay()
        case "Fiend City":
            MoveForFiendCity()
        case "Spirit World":
            MoveForSpiritWorld()
        case "Haunted Academy":
            MoveForHauntedAcademy()
        case "Space Center":
            MoveForSpaceCenter()
        case "Mountain Temple":
            MoveForMountainTemple()
        case "Cursed Festival":
            MoveForCursedFestival()
        case "Nightmare Train":
            MoveForNightmareTrain()
        case "Air Craft":
            MoveForAirCraft()
        case "Hellish City":
            MoveForHellish()
        case "Shibuya District":
            MoveForShibuya()
    }
}

MoveForGreenie() {
    SendInput ("{a down}")
    SendInput ("{w down}")
    Sleep (2200)
    SendInput ("{a up}")
    SendInput ("{w up}")
}

MoveForSnowyTown() {
    SendInput("{d down}")
    Sleep(2000)
    SendInput("{d up}")
    Sleep(500)
}

MoveForNavyBay() {
    SendInput ("{a down}")
    SendInput ("{w down}")
    Sleep (1700)
    SendInput ("{a up}")
    SendInput ("{w up}")
}

MoveForFiendCity() {
    SendInput ("{a down}")
    Sleep (1700)
    SendInput ("{a up}")
    Sleep (500)
    SendInput ("{s down}")
    Sleep (3100)
    SendInput ("{s up}")
    Sleep(500)
    SendInput("{a down}")
    Sleep(900)
    SendInput("{a up}")
}

MoveForSpiritWorld() {
    SendInput ("{d down}")
    SendInput ("{w down}")
    Sleep(7000)
    SendInput ("{d up}")
    SendInput ("{w up}")
    sleep(500)
    Fixclick(400, 15, "Right")
    sleep(4000)
}

MoveForAntKingdom() {
    Fixclick(130, 550, "Right")
    Sleep (3000)
    Fixclick(130, 550, "Right")
    Sleep (4000)
    Fixclick(30, 450, "Right")
    Sleep (3000)
    Fixclick(120, 100, "Right")
    sleep (3000)
}

MoveForMagicTown() {
    SendInput("{d down}")
    Sleep (2500)
    SendInput("{d up}")
    SendInput("{s down}")
    Sleep (3000)
    SendInput ("{d down}")
    Sleep (3000)
    SendInput ("{d up}")
}

MoveForMagicHill() {
    SendInput("{w down}")
    Sleep(200)
    SendInput("{w up}")
    Sleep(500)
    SendInput("{w down}")
    SendInput("{d down}")
    Sleep(2000)
    SendInput("{d up}")
    SendInput("{w up}")
    Sleep(500)
    SendInput("{w down}")
    Sleep(9500)
    SendInput("{w up}")
    Sleep(600)
}

MoveForHauntedAcademy() {
    color := PixelGetColor(647, 187)
    if (ok := FindText(&X, &Y, 620, 200, 750, 375, 0.15, 0.15, AcademyAngle2)) or (IsColorInRange(color, 0xFDF0B3)) {
        SendInput ("{s down}")
        sleep (3000)
        SendInput ("{s up}")
    } else {
        SendInput ("{d down}")
        sleep (3000)
        SendInput ("{d up}")
    }
}

MoveForSpaceCenter() {
    SendInput("{d down}")
    Sleep (4000)
    SendInput("{d up}")
    Sleep(500)
    SendInput("{w down}")
    Sleep(3000)
    SendInput("{w up}")
    Sleep(500)
}

MoveForMountainTemple() {
    SendInput("{a down}")
    SendInput("{s down}")
    Sleep (2500)
    SendInput("{a up}")
    SendInput("{s up}")
}

MoveForCursedFestival() {
    SendInput ("{a down}")
    sleep (1800)
    SendInput ("{a up}")
}

MoveForNightmareTrain() {
    SendInput ("{a down}")
    sleep (1800)
    SendInput ("{a up}")
}

MoveForAirCraft() {
    SendInput ("{w down}")
    sleep (800)
    SendInput ("{w up}")
}

MoveForHellish() {
    Fixclick(600, 300, "Right")
    Sleep (7000)
}

MoveForShibuya() {
    if (ok := FindText(&X, &Y, 220, 190, 320, 250, 0.15, 0.15, ShibuyaAngle)) {
        SendInput ("{a down}")
        sleep (600)
        SendInput ("{a up}")
        sleep (500)
        SendInput ("{a down}")
        SendInput ("{w down}")
        Sleep (1500)
        SendInput ("{a up}")
        SendInput ("{w up}")
    } else {
        SendInput ("{d down}")
        Sleep(2000)
        SendInput ("{d up}")
    }
}


RestartStage() {
    currentMap := DetectMap()

    ; Wait for loading
    CheckLoaded()

    ; Do initial setup and map-specific movement during vote timer
    BasicSetup()
    if (currentMap != "không tìm thấy map") {
        HandleMapMovement(currentMap)
    }

    ; Wait for game to actually start
    StartedGame()

    ; Begin unit placement and management
    PlacingUnits()

    ; Monitor stage progress
    MonitorStage()
}

Reconnect() {
    ; Check for Disconnected Screen using FindText
    if (ok := FindText(&X, &Y, 330, 218, 474, 247, 0, 0, Disconnect)) {
        ProcessLog("Bị mất kết nối - Tiến hành vào Private Sever...")

        psLink := FileExist("Settings\PrivateServer.txt") ? FileRead("Settings\PrivateServer.txt", "UTF-8") : ""

        ; Reconnect to Ps
        if FileExist("Settings\PrivateServer.txt") && (psLink := FileRead("Settings\PrivateServer.txt", "UTF-8")) {
            ProcessLog("Connecting to private server...")
            Run(psLink)
        } else {
            Run("roblox://placeID=8304191830")
        }

        Sleep(5000)

        loop {
            ProcessLog("Reconnecting to Roblox...")
            Sleep(15000)

            if WinExist(rblxID) {
                forceRobloxSize()
                moveRobloxWindow()
                Sleep(1000)
            }

            if (ok := FindText(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
                ProcessLog("Reconnect success")
                return StartSelectedMode()
            } else {
                Reconnect()
            }
        }
    }
}

PlaceUnit(x, y, slot := 1) {
    SendInput(slot)
    Sleep 50
    FixClick(x, y)
    Sleep 50
    SendInput("q")

    if UnitPlaced() {
        Sleep 15
        return true
    }
    return false
}

MaxUpgrade() {
    Sleep 500
    ; Check for max text
    if (ok := FindText(&X, &Y, 160, 215, 330, 420, 0, 0, MaxText) or (ok := FindText(&X, &Y, 160, 215, 330, 420, 0, 0, MaxText2))) {
        return true
    }
    return false
}

UnitPlaced() {
    Sleep 2000
    ; Check for upgrade text
    if (ok := FindText(&X, &Y, 160, 215, 330, 420, 0, 0, UpgradeText) or (ok := FindText(&X, &Y, 160, 215, 330, 420, 0, 0, UpgradeText2))) {
        ProcessLog("Đã đặt được Unit")
        CheckAbility()
        MahogoraAbility()
        FixClick(325, 185) ; close upg menu
        return true
    }
    return false
}

MahogoraAbility() {
    if (FindText(&x, &y, 294, 532, 294, 532, 0, 0, ChangeSkill)) {
        Send("Find Def Type")
        loop 2 {
            FixClick(x, y)
            Sleep(3000)
        }
        ProcessLog("Changed Attack type for Mahogora")
    }
}

CheckAbility() {
    global AutoAbilityBox  ; Reference your checkbox
    ; Only check ability if checkbox is checked
    if (AutoAbilityBox.Value) {
        if (ok := FindText(&X, &Y, 342, 253, 401, 281, 0, 0, AutoOff)) {
            FixClick(X, Y - 20)  ; Turn ability on
            ProcessLog("Auto-ability is on")
        }
        Sleep(500)
    }
}


CheckForXp() {
    ; Check for lobby text
    if (ok := FindText(&X, &Y, 340, 369, 437, 402, 0, 0, XpText) or (ok := FindText(&X, &Y, 539, 155, 760, 189, 0, 0, XpText2))) {
        FixClick(325, 185)
        FixClick(560, 560)
        return true
    }
    return false
}

UpgradeUnit(x, y) {
    FixClick(x, y - 3)
    FixClick(264, 363) ; upgrade button
    FixClick(264, 363) ; upgrade button
    FixClick(264, 363) ; upgrade button
}

CheckLobby() {
    loop {
        Sleep 1000
        if (ok := FindText(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
            break
        }
        Reconnect()
    }
    ProcessLog("Đã trở về Lobby, tiến hành lại chế độ đã chọn")
    return StartSelectedMode()
}

CheckLoaded() {
    loop {
        Sleep(1000)

        ; Check for vote screen
        if (ok := FindText(&X, &Y, 326, 60, 547, 173, 0, 0, VoteStart) or PixelGetColor(320, 60) = 0x00EE00) {
            ProcessLog("Hoàn tất vào trận")
            Sleep(1000)
            break
        }
        Reconnect()
    }
}

StartedGame() {
    loop {
        Sleep(1000)
        if (ok := FindText(&X, &Y, 326, 60, 547, 173, 0, 0, VoteStart)) {
            FixClick(350, 103) ; click yes
            FixClick(350, 100)
            FixClick(350, 97)
            continue  ; Keep waiting if vote screen is still there
        }

        ; If we don't see vote screen anymore the game has started
        ProcessLog("Game bắt đầu")
        global stageStartTime := A_TickCount
        break
    }
}

StartSelectedMode() {
    FixClick(400, 340)
    FixClick(400, 390)
    if (ModeDropdown.Text = "Story") {
        StoryMode()
    }
    else if (ModeDropdown.Text = "Legend") {
        LegendMode()
    }
    else if (ModeDropdown.Text = "Raid") {
        RaidMode()
    }
    else if (ModeDropdown.Text = "Infinity Castle") {
        InfinityCastleMode()
    }
    else if (ModeDropdown.Text = "Contract") {
        ContractMode()
    }
    else if (ModeDropdown.Text = "Dungeon") {
        DungeonMode()
    }
    else if (ModeDropdown.Text = "Portal") {
        PortalMode()
    }
    else if (ModeDropdown.Text = "Farm") {
        FarmMode()
    }
    else if (ModeDropdown.Text := "Daily Infinite Quest") {
        InfQuestMode()
    }
}

FormatStageTime(ms) {
    seconds := Floor(ms / 1000)
    minutes := Floor(seconds / 60)
    hours := Floor(minutes / 60)

    minutes := Mod(minutes, 60)
    seconds := Mod(seconds, 60)

    return Format("{:02}:{:02}:{:02}", hours, minutes, seconds)
}

ValidateMode() {
    if (ModeDropdown.Text = "") {
        ProcessLog("Choose mode, my Nigga")
        return false
    }
    if (!confirmClicked) {
        ProcessLog("Click on confirm, Nigga!")
        return false
    }
    return true
}

GetNavKeys() {
    return StrSplit(FileExist("Settings\UINavigation.txt") ? FileRead("Settings\UINavigation.txt", "UTF-8") : "\,#,}", ",")
}

HandleContractJoin() {
    selectedPage := ContractPageDropdown.Text
    joinType := ContractJoinDropdown.Text

    ; Handle 4-5 Page pattern selection
    if (selectedPage = "Page 4-5") {
        selectedPage := GetContractPage()
        ProcessLog("Selected Page: " selectedPage)
    }

    pageNum := selectedPage = "Page 4-5" ? GetContractPage() : selectedPage
    pageNum := Integer(RegExReplace(RegExReplace(pageNum, "Page\s*", ""), "-.*", ""))

    ; Define click coordinates for each page
    clickCoords := Map(
        1, { openHere: { x: 170, y: 420 }, matchmaking: { x: 240, y: 420 } },  ; Example coords for page 1
        2, { openHere: { x: 330, y: 420 }, matchmaking: { x: 400, y: 420 } },  ; Example coords for page 2
        3, { openHere: { x: 490, y: 420 }, matchmaking: { x: 560, y: 420 } }, ; Example coords for page 3
        4, { openHere: { x: 237, y: 420 }, matchmaking: { x: 305, y: 420 } },  ; Example coords for page 4
        5, { openHere: { x: 397, y: 420 }, matchmaking: { x: 465, y: 420 } },  ; Example coords for page 5
        6, { openHere: { x: 557, y: 420 }, matchmaking: { x: 625, y: 420 } }  ; Example coords for page 6
    )

    ; First scroll if needed for pages 4-6
    if (pageNum >= 4) {
        FixClick(445, 300)
        Sleep(200)
        Loop 5 {
            SendInput("{WheelDown}")
            Sleep(150)
        }
        Sleep(300)
    }

    ; Get coordinates for the selected page
    pageCoords := clickCoords[pageNum]

    ; Handle different join types
    if (joinType = "Creating") {
        ProcessLog("Initilizing Contract follow page: " pageNum)
        FixClick(pageCoords.openHere.x, pageCoords.openHere.y)
        Sleep(300)
        FixClick(255, 355)
        Sleep(15000)
        ProcessLog("Waiting for other players for 15 seconds")
        FixClick(400, 460)
    } else if (joinType = "Matchmaking") {
        ProcessLog("Đang tham gia theo ô: " pageNum)
        FixClick(pageCoords.matchmaking.x, pageCoords.matchmaking.y)  ; Click matchmaking button
        Sleep(300)

        ; Try captcha
        if (!CaptchaDetect(252, 292, 300, 50, 400, 335)) {
            ProcessLog("Không thấy Capcha, đang thử lại...")
            FixClick(585, 190)  ; Click close
            return
        }
        FixClick(300, 385)  ; Enter captcha

        startTime := A_TickCount
        while (A_TickCount - startTime < 20000) {  ; Check for 20 seconds
            if !(ok := FindText(&X, &Y, 746, 514, 789, 530, 0, 0, AreaText)) {
                ProcessLog("Find match success")
                return true
            }
            Sleep(200)  ; Check every 200ms
        }

        ProcessLog("Failed during finding match, rejoin...")
        FixClick(445, 220)
        Sleep(1000)
        Loop 5 {
            SendInput("{WheelUp}")
            Sleep(150)
        }
        Sleep(1000)
        return HandleContractJoin()
    }

    ProcessLog("Getting in Contract...")
    return true
}

HandleNextContract() {
    selectedPage := ContractPageDropdown.Text
    if (selectedPage = "Page 4-5") {
        selectedPage := GetContractPage()
    }

    pageNum := Integer(RegExReplace(selectedPage, "Page ", ""))

    ; Define click coordinates to vote
    clickCoords := Map(
        1, { x: 205, y: 470 },
        2, { x: 365, y: 470 },
        3, { x: 525, y: 470 },
        4, { x: 272, y: 470 },
        5, { x: 432, y: 470 },
        6, { x: 592, y: 470 }
    )

    ; First scroll if needed for pages 4-6
    if (pageNum >= 4) {
        FixClick(400, 300)
        Sleep(200)
        Loop 5 {
            SendInput("{WheelDown}")
            Sleep(150)
        }
        Sleep(300)
    }

    ; Click the Open Here button for the selected page
    ProcessLog("Opening Contract following page: " selectedPage)
    FixClick(clickCoords[pageNum].x, clickCoords[pageNum].y)
    Sleep(3000)
    return RestartStage()
}

HandleContractEnd() {

    Loop {
        Sleep(3000)

        ; Click to claim any drops/rewards
        FixClick(560, 560)

        if (ok := FindText(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
        }

        if (ok := FindText(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
            ClickUntilGone(0, 0, 260, 400, 390, 450, NextText, 0, -40)
        }

        ; Check for both lobby texts
        if (ok := FindText(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or (ok := FindText(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
            ProcessLog("Lobby Found - wating for ending stage")
            Sleep(2000)  ; Wait for UI to settle

            if (ReturnLobbyBox.Value) {
                ProcessLog("Contract Completed - returning back to Lobby...")
                Sleep(1500)
                ClickReturnToLobby()
                CheckLobby()
                return StartSelectedMode()
            } else {
                ProcessLog("Moving to next Contract...")
                Sleep(1500)
                ClickReplay()
                return HandleNextContract()
            }
        }
        Reconnect()
    }
}

GetContractPage() {
    global contractPageCounter, contractSwitchPattern

    if (contractSwitchPattern = 0) {  ; During page 4 phase
        contractPageCounter++
        if (contractPageCounter >= 6) {  ; After 6 times on page 4
            contractPageCounter := 0
            contractSwitchPattern := 1  ; Switch to page 5
            return "Page 5"
        }
        return "Page 4"
    } else {  ; During page 5 phase
        contractPageCounter := 0
        contractSwitchPattern := 0  ; Switch back to page 4 pattern
        return "Page 4"
    }
}

GenerateRandomPoints() {
    points := []
    gridSize := 40  ; Minimum spacing between units

    ; Center point coordinates
    centerX := 408
    centerY := 320

    ; Define placement area boundaries (adjust these as needed)
    minX := centerX - 180  ; Left boundary
    maxX := centerX + 180  ; Right boundary
    minY := centerY - 140  ; Top boundary
    maxY := centerY + 140  ; Bottom boundary

    ; Generate 40 random points
    Loop 40 {
        ; Generate random coordinates
        x := Random(minX, maxX)
        y := Random(minY, maxY)

        ; Check if point is too close to existing points
        tooClose := false
        for existingPoint in points {
            ; Calculate distance to existing point
            distance := Sqrt((x - existingPoint.x) ** 2 + (y - existingPoint.y) ** 2)
            if (distance < gridSize) {
                tooClose := true
                break
            }
        }

        ; If point is not too close to others, add it
        if (!tooClose)
            points.Push({ x: x, y: y })
    }

    ; Always add center point last (so it's used last)
    points.Push({ x: centerX, y: centerY })
    return points
}

GenerateGridPoints() {
    points := []
    gridSize := 40  ; Space between points
    squaresPerSide := 10  ; How many points per row/column (odd number recommended)

    ; Center point coordinates
    centerX := 408
    centerY := 320

    ; Calculate starting position for top-left point of the grid
    startX := centerX - ((squaresPerSide - 1) / 2 * gridSize)
    startY := centerY - ((squaresPerSide - 1) / 2 * gridSize)

    ; Generate grid points row by row
    Loop squaresPerSide {
        currentRow := A_Index
        y := startY + ((currentRow - 1) * gridSize)

        ; Generate each point in the current row
        Loop squaresPerSide {
            x := startX + ((A_Index - 1) * gridSize)
            points.Push({ x: x, y: y })
        }
    }

    return points
}

; circle coordinates
GenerateCirclePoints() {
    points := []

    ; Define each circle's radius
    radius1 := 45    ; First circle
    radius2 := 90    ; Second circle
    radius3 := 135   ; Third circle
    radius4 := 180   ; Fourth circle

    ; Angles for 8 evenly spaced points (in degrees)
    angles := [0, 45, 90, 135, 180, 225, 270, 315]

    ; First circle points
    for angle in angles {
        radians := angle * 3.14159 / 180
        x := centerX + radius1 * Cos(radians)
        y := centerY + radius1 * Sin(radians)
        points.Push({ x: Round(x), y: Round(y) })
    }

    ; second circle points
    for angle in angles {
        radians := angle * 3.14159 / 180
        x := centerX + radius2 * Cos(radians)
        y := centerY + radius2 * Sin(radians)
        points.Push({ x: Round(x), y: Round(y) })
    }

    ; third circle points
    for angle in angles {
        radians := angle * 3.14159 / 180
        x := centerX + radius3 * Cos(radians)
        y := centerY + radius3 * Sin(radians)
        points.Push({ x: Round(x), y: Round(y) })
    }

    ;  fourth circle points
    for angle in angles {
        radians := angle * 3.14159 / 180
        x := centerX + radius4 * Cos(radians)
        y := centerY + radius4 * Sin(radians)
        points.Push({ x: Round(x), y: Round(y) })
    }

    return points
}


CheckEndAndRoute() {
    if (ok := FindText(&X, &Y, 140, 130, 662, 172, 0, 0, LobbyText)) {
        ProcessLog("Found end screen")
        if (mode = "Contract") {
            return HandleContractEnd()
        } else if (mode = "Dungeon") {
            return MonitorDungeonEnd()
        } else {
            return MonitorEndScreen()
        }
    }
}

ClickUntilGone(x, y, searchX1, searchY1, searchX2, searchY2, textToFind, offsetX := 0, offsetY := 0, textToFind2 := "") {
    while (ok := FindText(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0.15, 0.15, textToFind) ||
        textToFind2 && FindText(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0.15, 0.15, textToFind2)) {
        if (offsetX != 0 || offsetY != 0) {
            FixClick(X + offsetX, Y + offsetY)
        } else {
            FixClick(x, y)
        }
        Sleep(1000)
    }
}

ClickOnce(x, y, searchX1, searchY1, searchX2, searchY2, textToFind, offsetX := 0, offsetY := 0, textToFind2 := "") {
    if (ok := FindText(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0.15, 0.15, textToFind) ||
        textToFind2 && FindText(&X, &Y, searchX1, searchY1, searchX2, searchY2, 0.15, 0.15, textToFind2)) {

        if (offsetX != 0 || offsetY != 0) {
            FixClick(X + offsetX, Y + offsetY)
        } else {
            FixClick(x, y)
        }
    }
}

StartMacro(*) {
    if (!ValidateMode()) {
        return
    }
    StartSelectedMode()
}

TogglePause(*) {
    Pause -1
    if (A_IsPaused) {
        ProcessLog("Đã dừng Macro")
        Sleep(1000)
    } else {
        ProcessLog("Tiếp tục Macro")
        Sleep(1000)
    }
}

IsColorInRange(color, targetColor, tolerance := 50) {
    ; Extract RGB components
    r1 := (color >> 16) & 0xFF
    g1 := (color >> 8) & 0xFF
    b1 := color & 0xFF

    ; Extract target RGB components
    r2 := (targetColor >> 16) & 0xFF
    g2 := (targetColor >> 8) & 0xFF
    b2 := targetColor & 0xFF

    ; Check if within tolerance range
    return Abs(r1 - r2) <= tolerance
        && Abs(g1 - g2) <= tolerance
        && Abs(b1 - b2) <= tolerance
}

; Custom monitor for dungeon ending
MonitorDungeonEnd() {
    global mode, Wins, loss

    Loop {
        Sleep(3000)

        FixClick(560, 560)  ; Move click

        ; Check for unit exit UI element
        if (ok := FindText(&X, &Y, 300, 190, 360, 250, 0, 0, UnitExit)) {
            ClickUntilGone(0, 0, 300, 190, 360, 250, UnitExit, -4, -35)
        }

        ; Check for next text UI element
        if (ok := FindText(&X, &Y, 260, 400, 390, 450, 0, 0, NextText)) {
            ClickUntilGone(0, 0, 260, 400, 390, 450, NextText, 0, -40)
        }

        ; Check for returning to lobby
        if (ok := FindText(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText) or
            (ok := FindText(&X, &Y, 80, 85, 739, 224, 0, 0, LobbyText2))) {
            ProcessLog("Dungeon hoàn thành, tiến hành chơi lại")

            ; Click replay button
            ClickReplay()

            ; After clicking replay, check for shop/shrine/chest
            CheckDungeonSpecials()

            if (CheckForFinishDungeon()) {
                ProcessLog("Xử lý xong Dungeon")
                return
            }

            ; Start a new dungeon run
            ProcessLog("Moving to next Dungeon")
            return SelectDungeonRoute()
        }
        Reconnect()
    }
}

; Function to check for special dungeon elements after replay
CheckDungeonSpecials() {
    ProcessLog("Đang kiểm tra dungeon shop, shrine, mở rương")

    ; Give time for special elements to appear
    Sleep(2000)

    ; Check the area for shop, shrine, or chest
    Loop 5 {
        ; Check for shop
        if (ok := FindText(&X, &Y, 140, 200, 375, 250, 0, 0, Shop)) {
            ProcessLog("Tìm thấy Shop")
            Sleep(1000)
            HandleShop()
            Sleep(1000)
            return true
        }
        ; Check for shrine
        if (ok := FindText(&X, &Y, 140, 200, 375, 250, 0, 0, Shrine)) {
            ProcessLog("Tìm Shrine, tiến hành từ chối")
            ClickUntilGone(0, 0, 490, 420, 605, 455, DenyShrine, 0, -30)
            Sleep(1000)
            return true
        }
        ; Check for Chest Opening
        if (ok := FindText(&X, &Y, 140, 200, 375, 250, 0, 0, ChestRoom)) {
            ProcessLog("Tìm thấy mở Rương")
            HandleChestScreen()
            return true
        }

        Sleep(1000)  ; Wait and check again
    }

    ProcessLog("Không tìm thấy shop, shrine, open chest")
    return false
}

SelectDungeonRoute() {
    if (ok := FindText(&X, &Y, 140, 180, 480, 350, 0.20, 0.20, BossRoom) or (ok := FindText(&X, &Y, 140, 180, 480, 350, 0.20, 0.20, BossRoom2))) {
        ProcessLog("Đã thấy Boss room!")
        global BossRoomCompleted := true
        FixClick(X, Y - 30)
        Sleep(1000)
    }
    if (ok := FindText(&X, &Y, 200, 350, 600, 435, 0.20, 0.20, Chest)) {
        ProcessLog("Tìm thấy phòng Chest, bấm vào")
        FixClick(X, Y - 30)
        Sleep(1000)
    }
    else if (ok := FindText(&X, &Y, 200, 350, 600, 435, 0.20, 0.20, Hoard)) {
        ProcessLog("Tìm thấy Hoard Room, bấm vào")
        FixClick(X, Y - 30)
        Sleep(1000)
    }
    else {
        ; If no chest/hoard found, click default positions
        ProcessLog("Không thấy chest/hoard, bấm lại vị trí mặc định")
        FixClick(400, 355)
        Sleep(500)
        FixClick(335, 355)
        Sleep(500)
    }

    ; Look for Enter button and click until gone
    if (ok := FindText(&X, &Y, 120, 425, 680, 500, 0.20, 0.20, Enter)) {
        ProcessLog("Tìm thấy Enter, tiến hành vào Dungeon")
        ClickUntilGone(0, 0, 120, 425, 680, 500, Enter, 0, -30)
        Sleep(2000)

        ; Start dungeon run
        ProcessLog("Bắt đầu dungeon")
        RestartStage()
    }
}

HandleShop() {
    Sleep(1000)
    ProcessLog("Buying in shop")

    ; Give the shop time to fully load
    Sleep(1000)

    ; Buy item in slot 3 (bottom)
    FixClick(560, 335)
    Sleep(1000)

    ; Buy item in slot 2 (middle)
    FixClick(560, 280)
    Sleep(1000)

    ; Buy item in slot 1 (top)
    FixClick(560, 225)
    Sleep(1000)

    ; Click continue to close the shop
    ProcessLog("Close shop")
    ClickUntilGone(0, 0, 380, 385, 615, 490, DungeonContinue, -3, -35)
    Sleep(1000)
    return true
}

HandleChestScreen() {
    global BossRoomCompleted, SaveChestsForBoss

    ; Determine if we should open chests now
    shouldOpenChests := BossRoomCompleted || !SaveChestsForBoss

    if (shouldOpenChests) {
        ProcessLog("Đang mở chest có sẵn")

        ; Process first chest position - keep clicking until exhausted
        firstChestExhausted := false

        while (!firstChestExhausted) {
            ; Click first chest OPEN button
            ClickOnce(0, 0, 535, 265, 605, 315, OpenChest, -3, -35)
            Sleep(2000)

            ; Check if we're still on the chest screen
            if (!IsChestScreenVisible()) {
                ClaimChestReward()
            } else {
                firstChestExhausted := true
            }
        }

        ; Process second chest position - keep clicking until exhausted
        secondChestExhausted := false

        while (!secondChestExhausted) {
            ; Click second chest OPEN button
            ClickOnce(0, 0, 530, 330, 605, 375, OpenChest, -3, -35)
            Sleep(1000)

            ; Check if we're still on the chest screen
            if (!IsChestScreenVisible()) {
                ClaimChestReward()
            } else {
                secondChestExhausted := true
            }
        }

        ProcessLog("Đã mở hết Chest")

        ; Reset the boss room flag if it was set
        if (BossRoomCompleted) {
            BossRoomCompleted := false
            ClickUntilGone(0, 0, 380, 385, 615, 490, DungeonContinue, -3, -35)
        }
    } else {
        ; Skip opening chests, just click continue
        ProcessLog("Saving chests for boss room - clicking continue")
        ClickUntilGone(0, 0, 380, 385, 615, 490, DungeonContinue, -3, -35)
    }
    Sleep(1000)
    Reconnect()
    return true
}

ClaimChestReward() {
    maxClicks := 30  ; Safety limit
    clicks := 0

    while (clicks < maxClicks) {
        ; Click to claim reward
        FixClick(560, 560)
        Sleep(500)

        ; Check if chest screen has returned
        if (IsChestScreenVisible()) {
            return true
        }

        clicks++
    }

    ProcessLog("Đã nhận hết phần thưởng")
    return false
}

IsChestScreenVisible() {
    return FindText(&X, &Y, 140, 200, 375, 250, 0, 0, ChestRoom)
}

CheckForFinishDungeon() {
    ; Check for the finish dungeon popup
    if (ok := FindText(&X, &Y, 240, 180, 565, 480, 0, 0, FinishDungeon) or (ok := FindText(&X, &Y, 310, 395, 495, 440, 0.20, 0.20, EnterDungeon))) {

        ; Click the Finish button
        ClickUntilGone(0, 0, 240, 180, 565, 480, DungeonFinish, -3, -35)
        Sleep(1500)

        ; Click the X in the top right
        ClickUntilGone(0, 0, 640, 175, 700, 205, DungeonRedX, -3, -35)
        Sleep(1000)

        ; Return to lobby
        ProcessLog("Trở lại Lobby sau khi hoàn tất Dungeon")
        ClickReturnToLobby()

        ; Check for lobby and restart
        return CheckLobby()
    }

    return false
}
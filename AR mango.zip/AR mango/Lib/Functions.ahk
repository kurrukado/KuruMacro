global settingsFile := ""
global confirmClicked := false

setupFilePath() {
    global settingsFile

    if !DirExist(A_ScriptDir "\Settings") {
        DirCreate(A_ScriptDir "\Settings")
    }

    settingsFile := A_ScriptDir "\Settings\Configuration.txt"
    return settingsFile
}

; SaveUINavSettings(*) {
;     ProcessLog("Saving UI Navigation Key")

;     if FileExist("Settings\UINavigation.txt")
;         FileDelete("Settings\UINavigation.txt")

;     FileAppend(UINavBox.Value, "Settings\UINavigation.txt", "UTF-8")
; }

;Opens discord Link
OpenDiscordLink() {
    Run("https://discord.gg/xRYGPntnTT")
}

;Minimizes the UI
minimizeUI(*) {
    arMainUI.Minimize()
}

Destroy(*) {
    arMainUI.Destroy()
    ExitApp
}
;Login Text
setupOutputFile() {
    content := "`n==" arTitle "" version "==`n  Start Time: [" currentTime "]`n"
    FileAppend(content, currentOutputFile)
}

;Gets the current time
getCurrentTime() {
    currentHour := A_Hour
    currentMinute := A_Min
    currentSecond := A_Sec

    return Format("{:d}h.{:02}m.{:02}s", currentHour, currentMinute, currentSecond)
}

OnModeChange(*) {
    global mode
    selected := ModeDropdown.Text

    ; Hide all dropdowns first
    StoryDropdown.Visible := false
    StoryActDropdown.Visible := false

    ;Chọn mode dựa trên đã chọn
    if (selected = "Story") {
        StoryDropdown.Visible := true
        StoryActDropdown.Visible := true
        mode := "Story"
    } else if (selected = "Farm") {
        mode := "Farm"
    } else if (selected = "Challenge") {
        mode := "Challenge"
    } else if (selected = "Ranger") {
        mode := "Ranger"
    }
}

OnStoryChange(*) {
    if (StoryDropdown.Text != "") {
        StoryActDropdown.Visible := true
    } else {
        StoryActDropdown.Visible := false
    }
}


OnConfirmClick(*) {
    if (ModeDropdown.Text = "") {
        ProcessLog("Choose mode before you press confirm")
        return
    } else { 
    ProcessLog("Choosed: " ModeDropdown.Text)
    }

    ; Hide all controls if validation passes
    ModeDropdown.Visible := false
    StoryDropdown.Visible := false
    StoryActDropdown.Visible := false
    ConfirmButton.Visible := false
    modeSelectionGroup.Visible := false
    Hotkeytext.Visible := true
    Hotkeytext2.Visible := true
    global confirmClicked := true
    
}

FixClick(x, y, LR := "Left") {
    CoordMode "Mouse", "Screen"
    CoordMode "Pixel", "Screen"
    MouseMove(x, y)
    MouseMove(1, 0, 30, "R")
    MouseClick(LR, -1, 0, , , , "R")
    Sleep(50)
}

SaveKeybindSettings(*) {
    ProcessLog("Saving Keybind Configuration")

    if FileExist("Settings\Keybinds.txt")
        FileDelete("Settings\Keybinds.txt")

    FileAppend(Format("F1={}`nF2={}`nF3={}`nF4={}", F1Box.Value, F2Box.Value, F3Box.Value, F4Box.Value), "Settings\Keybinds.txt", "UTF-8")

    ; Update globals
    global F1Key := F1Box.Value
    global F2Key := F2Box.Value
    global F3Key := F3Box.Value
    global F4Key := F4Box.Value

    ; Update hotkeys
    Hotkey(F1Key, (*) => moveRobloxWindow())
    Hotkey(F2Key, (*) => StartMacro())
    Hotkey(F3Key, (*) => Reload())
    Hotkey(F4Key, (*) => TogglePause())
}

LoadKeybindSettings() {
    if FileExist("Settings\Keybinds.txt") {
        fileContent := FileRead("Settings\Keybinds.txt", "UTF-8")
        Loop Parse, fileContent, "`n" {
            parts := StrSplit(A_LoopField, "=")
            if (parts[1] = "F1")
                global F1Key := parts[2]
            else if (parts[1] = "F2")
                global F2Key := parts[2]
            else if (parts[1] = "F3")
                global F3Key := parts[2]
            else if (parts[1] = "F4")
                global F4Key := parts[2]
        }
    }
}

ToggleSaveChestsForBoss(*) {
    global SaveChestsForBoss
    SaveChestsForBoss := !SaveChestsForBoss
    ProcessLog("Save chests for boss room: " (SaveChestsForBoss ? "Enabled" : "Disabled"))
}

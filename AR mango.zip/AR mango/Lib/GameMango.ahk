#Requires AutoHotkey v2.0

global macroStartTime := A_TickCount
global stageStartTime := A_TickCount
global contractPageCounter := 0
global contractSwitchPattern := 0
global BossRoomCompleted := false
global SaveChestsForBoss := true

;HotKeys
Hotkey(F1Key, (*) => moveRobloxWindow())
Hotkey(F2Key, (*) => StartMacro())
Hotkey(F3Key, (*) => Reload())
Hotkey(F4Key, (*) => TogglePause())

StoryMovement() {
    FixClick(65, 360) ; click play
    Sleep (1000)
    FixClick(85, 260) ; click create room
    Sleep (1000)
}

ChallReplay() {
    FixClick(270, 430)
}

RangerReplay() {
    FixClick(275, 430)
}

ChallLeave() {
    FixClick(400, 430)
}

LobbyRangerReturn() {
    FixClick(405, 425)
}

RestartStage() {
    currentMap := DetectMap()
    if (FindText(&x, &y, 0, 123, 275, 245, 0, 0, Lobby)) {
        Sleep(12000) ; 12 seconds
        return StartSelectedMode()
    }
    ; Wait for loading
    CheckLoaded()
    ; Wait for game to actually start
    StartedGame()
    ; Monitor stage progress
    MonitorStage()
}

PlayHere() {
    if (FindText(&x, &y, 445, 424, 542, 462, 0, 0, Create)) {
        FixClick(x, y)
    }
    Sleep(500)
    FixClick(402, 508)
}

StoryMode() {
    global StoryDropdown, StoryActDropdown
    
    ; Get current map and act
    currentStoryMap := StoryDropdown.Text
    currentStoryAct := StoryActDropdown.Text
    
    ; Execute the movement pattern
    ProcessLog("Moving to position for " currentStoryMap)
    StoryMovement()
    

    ; Closes Player leaderboard
    FixClick(640, 103)
    Sleep(500)

    FixClick(85, 260) ; Create Room
    Sleep(1000)

    while !(ok := FindText(&X, &Y, 325, 163, 409, 193, 0.05, 0.20, StoryChapter)) {
        ProcessLog("Looking for Story Chapter Text...")
        FixClick(615, 155) ; Click X on Join
        Sleep(1000)
        FixClick(25, 225) ; Create Room
        Sleep(1000)
        Reconnect() ; Added Disconnect Check
    }

    ProcessLog("Starting " currentStoryMap " - " currentStoryAct)
    StartStory(currentStoryMap, currentStoryAct)

    PlayHere()
    RestartStage()
}

ChallengeMovement() {
    FixClick(640, 103) ; close leader board
    Sleep(700)
    FixClick(31, 359)
    Sleep(700)
    FixClick(363, 321)
    Sleep(700)
    FixClick(66, 360) ; play
    Sleep(700)
    FixClick(75, 350) ; leave
    Sleep(700)
    SendInput("{w down}")
    Sleep(1000)
    SendInput("{w up}")
    Sleep(1000)
    FixClick(295, 310)
    Sleep(700)
    FixClick(406, 508)
}

ChallengeMode() {
    FixClick(640, 103) ; close leader board
    ProcessLog("Moving to: Challenge")
    ChallengeMovement()
    RestartStage()
}

RangerMode() {
    global mode, Wins
    ProcessLog("Moving to Ranger mode")
    if (Wins == 12) {
        ProcessLog("12 wins in Ranger mode, switching to ChallengeForRanger mode")
        mode := "ChallengeForRanger"
        return ChallengeForRangerMode()
    } else {
        RangerMovement()
    }

    RestartStage()
}

RangerMovement() {
    FixClick(640, 103) ; close leader board
    global Wins
    y := 432
    FixClick(72, 359) ; to play
    Sleep(700)
    FixClick(86, 265) ; create room
    Sleep(700)
    FixClick(474, 500) ; select ranger
    Sleep(700)

    Loop Wins {
        i := A_Index
        Sleep(200)
        if (Mod(i, 3) == 0) {
            y -= 60
        }
    }
    FixClick(240, y) ; select stage
    Sleep(500)
    FixClick(480, 450) ; create
    Sleep(500)
    FixClick(400, 507) ; confirm / start
}

ChallengeForRangerMode() {
    global mode
    mode := "ChallengeForRanger"
    ProcessLog("Moving to: ChallengeForRanger")
    ChallengeMovement()
    RestartStage()
}


MonitorEndScreen() {
    global mode, StoryDropdown, StoryActDropdown, ReturnLobbyBox, MatchMaking
    global RangerReplayCount

    Loop {
        Sleep(3000)

        if (mode = "Farm") {
            ProcessLog("Handling Farm end")
            ProcessLog("Replay")
            ChallReplay()
            return RestartStage()
        } else if (mode = "Challenge") {
            ProcessLog("Replaying challenge")
            ChallReplay()
            return MonitorStage()
        } else if (mode = "ChallengeForRanger") {
            ChallReplay()
            return MonitorStage()
        } else if (mode = "Ranger") {
            if (!IsSet(RangerReplayCount)) {
                RangerReplayCount := 0
            }
            RangerReplayCount += 1
            ProcessLog("Handling Ranger end - Replay count: " RangerReplayCount)

            if (RangerReplayCount < 3) {
                RangerReplay()
                return MonitorStage()
            } else if (RangerReplayCount = 3) {
                ProcessLog("Ranger win = 3, replaying then wait for lobby")
                RangerReplay()
                RangerReplayCount := 0
                return RestartStage()
            }
        }
    }
    else {
        ProcessLog("Handling after lose")
        return RestartStage()
    }
    Reconnect()
}

MonitorStage() {
    global Wins, loss, mode, StoryActDropdown 
    lastClickTime := A_TickCount

    ProcessLog("Waiting for end status...")
    Loop {
        Sleep(1000)

        if ((mode = "Story") || (mode = "Farm") || (mode = "Challenge") || (mode = "Ranger") || (mode = "ChallengeForRanger")) {
            timeElapsed := A_TickCount - lastClickTime
            if (timeElapsed >= 1000) {  ; 1 second
                FixClick(400, 180) ; Make sure click play for chall refresh
                lastClickTime := A_TickCount
            }
        }

        ; Check for Victory
        if ((FindText(&X, &Y, 369, 207, 578, 283, 0, 0, VictoryText) || (FindText(&X, &Y, 369, 207, 578, 283, 0, 0, VictoryText2)))) {
            stageEndTime := A_TickCount
            stageLength := FormatStageTime(stageEndTime - stageStartTime)
            ProcessLog("Victory detected - Stage Length: " stageLength)
            Wins += 1
            SendWebhookWithTime(true, stageLength)

            if (mode = "Ranger" && Wins = 15) {
                ProcessLog("Ranger win count reached 15, switching to Challenge mode")
                mode := "ChallengeForRanger"
                LobbyRangerReturn()
                return ChallengeForRangerMode()
            } else if (mode = "ChallengeForRanger" && Wins = 30) {
                ProcessLog("ChallengeForRanger win count reached 15, switching to Ranger mode")
                mode := "Ranger"
                Wins := 0
                ChallLeave()
                return RangerMode()
            } else {
                return MonitorEndScreen()
            }
        }
        Reconnect()
    }
}

GetStoryDownArrows(map) {
    switch map {
        case "Voocha Village": return 1
        case "Green Planet": return 2
        case "Demon Forest": return 3
        case "Leaf Village": return 4
        case "Z City": return 5
    }
}

GetStoryActDownArrows(StoryActDropdown) {
    switch StoryActDropdown {
        case "Act 1": return 0
        case "Act 2": return 1
        case "Act 3": return 2
        case "Act 4": return 3
        case "Act 5": return 4
        case "Act 6": return 5
        case "Act 7": return 6
        case "Act 8": return 7
        case "Act 9": return 8
        case "Act 10": return 9
    }
}

StartStory(map, act) {
    ProcessLog("Selecting map: " map " and act: " act)

    ; Get Story map 
    StoryMap := GetMapData("StoryMap", map)
    
    ; Scroll if needed
    if (StoryMap.scrolls > 0) {
        ProcessLog("Scrolling down " StoryMap.scrolls " for " map)
        MouseMove(230, 175)
        loop StoryMap.scrolls {
            SendInput("{WheelDown}")
            Sleep(250)
        }
    }
    Sleep(1000)
    
    ; Click on the map
    FixClick(StoryMap.x, StoryMap.y)
    Sleep(1000)
    
    ; Get act details
    StoryAct := GetMapData("StoryAct", act)
    
    ; Scroll if needed for act
    if (StoryAct.scrolls > 0) {
        ProcessLog("Scrolling down " StoryAct.scrolls " times for " act)
        MouseMove(400, 175)
        loop StoryAct.scrolls {
            SendInput("{WheelDown}")
            Sleep(250)
        }
    }
    Sleep(1000)
    
    ; Click on the act
    FixClick(StoryAct.x, StoryAct.y)
    Sleep(1000)

    FixClick(615, 250) ; Click nightmare
    Sleep(1000)
    
    return true
}

GetMapData(type, name) {
    data := Map(
        "StoryMap", Map(
            "Voocha Village", {x: 230, y: 165, scrolls: 0},
            "Green Planet", {x: 230, y: 230, scrolls: 0},
            "Demon Forest", {x: 230, y: 290, scrolls: 0},
            "Leaf Village", {x: 230, y: 360, scrolls: 0},
            "Z City", {x: 230, y: 360, scrolls: 1}
        ),
        "StoryAct", Map(
            "Act 1", {x: 400, y: 180, scrolls: 0},
            "Act 2", {x: 400, y: 245, scrolls: 0},
            "Act 3", {x: 400, y: 300, scrolls: 0},
            "Act 4", {x: 400, y: 225, scrolls: 1},
            "Act 5", {x: 400, y: 275, scrolls: 1},
            "Act 6", {x: 400, y: 200, scrolls: 2},
            "Act 7", {x: 400, y: 250, scrolls: 2},
            "Act 8", {x: 400, y: 300, scrolls: 2},
            "Act 9", {x: 400, y: 235, scrolls: 3},
            "Act 10", {x: 400, y: 290, scrolls: 3},
        ),
        "RaidMap", Map(
            "Ant Kingdom", {x: 630, y: 250, scrolls: 0}
        ),
        "RaidAct", Map(
            "Act 1", {x: 285, y: 235, scrolls: 0},
            "Act 2", {x: 285, y: 270, scrolls: 0},
            "Act 3", {x: 285, y: 305, scrolls: 0},
            "Act 4", {x: 285, y: 340, scrolls: 0},
            "Act 5", {x: 285, y: 375, scrolls: 0}
        ),
        "LegendMap", Map(
            "Voocha Village", {x: 230, y: 165, scrolls: 0},
            "Green Planet", {x: 230, y: 230, scrolls: 0},
            "Demon Forest", {x: 230, y: 290, scrolls: 0},
            "Leaf Village", {x: 230, y: 360, scrolls: 0},
            "Z City", {x: 230, y: 360, scrolls: 1}
        ),
        "LegendAct", Map(
            "Act 1", {x: 400, y: 180, scrolls: 0},
            "Act 2", {x: 400, y: 245, scrolls: 0},
            "Act 3", {x: 400, y: 300, scrolls: 0},
            "Act 4", {x: 400, y: 225, scrolls: 1},
            "Act 5", {x: 400, y: 275, scrolls: 1},
            "Act 6", {x: 400, y: 200, scrolls: 2},
            "Act 7", {x: 400, y: 250, scrolls: 2},
            "Act 8", {x: 400, y: 300, scrolls: 2},
            "Act 9", {x: 400, y: 235, scrolls: 3},
            "Act 10", {x: 400, y: 290, scrolls: 3},
            "Random", GetRandomAct()
        )
    )

    return data.Has(type) && data[type].Has(name) ? data[type][name] : {}
}

GetRandomAct() {
    randomAct := Random(1, 3) ; Generates a random number between 1 and 3
    return {x: 285, y: 235 + (randomAct - 1) * 35, scrolls: 0}
}


DetectMap() {
    ProcessLog("Getting in map...")
    startTime := A_TickCount

    Loop {
        ; Check if we waited more than 2 minute for votestart
        if (A_TickCount - startTime > 120000) {
            if ((FindText(&X, &Y, 0, 0, A_ScreenWidth, A_ScreenHeight, 0, 0, LobbyText)) || (FindText(&X, &Y, A_ScreenWidth, A_ScreenHeight, 0, 0, LobbyText2))) {
                ProcessLog("Lobby Found - Return selected mode")
                return StartSelectedMode()
            } else {
                ProcessLog("Cannot find map - Handling on")
                Sleep(1000)
                return StartSelectedMode()
            }
        }

        mapPatterns := Map(
            "Voocha Village", VoochaVillage,
            "Green Planed", GreenPlanet,
            "Demon Forest", DemonForest,
            "Leaf Village", LeafVillage,
            "Z City", ZCity,
            "Lobby", Lobby,
        )

        for mapName, pattern in mapPatterns {
            if (ok := FindText(&X, &Y, 0, 0, A_ScreenWidth, A_ScreenHeight, 0, 0, pattern)) {
                ProcessLog("Found map: " mapName)
                return mapName
            }
        }

        ; Check for vote screen
        if (ok := FindText(&X, &Y, 326, 60, 547, 173, 0, 0, VoteStart)) {
            ProcessLog("Cannot find map")
            return "no map found"
        }

        Sleep 1000
        Reconnect()
    }
}

Reconnect() {
    ; Check for Disconnected Screen using FindText
    if (ok := FindText(&X, &Y, 330, 218, 474, 247, 0, 0, Disconnect)) {
        ProcessLog("Lost connect, moving to private sever...")

        psLink := FileExist("Settings\PrivateServer.txt") ? FileRead("Settings\PrivateServer.txt", "UTF-8") : ""

        ; Reconnect to Ps
        if FileExist("Settings\PrivateServer.txt") && (psLink := FileRead("Settings\PrivateServer.txt", "UTF-8")) {
            ProcessLog("Connecting to private server...")
            Run(psLink)
        } else {
            Run("roblox://placeID=8304191830")
        }

        Sleep(5000)

        loop {
            ProcessLog("Reconnecting to Roblox...")
            Sleep(15000)

            if WinExist(rblxID) {
                forceRobloxSize()
                moveRobloxWindow()
                Sleep(1000)
            }

            if (ok := FindText(&X, &Y, 746, 514, 789, 530, 0, 0, LobbyText2)) {
                ProcessLog("Reconnect success")
                return StartSelectedMode()
            } else {
                Reconnect()
            }
        }
    }
}

CheckLobby() {
    loop {
        Sleep 1000
        if (ok := FindText(&X, &Y, 746, 514, 789, 530, 0, 0, Lobby)) {
            ProcessLog("Returned back to Lobby")
            return true
        }
        Reconnect()
    }
}

CheckLoaded() {
    loop {
        Sleep(1000)

        ; Check for vote screen
        if (ok := FindText(&X, &Y, 349, 163, 455, 201, 0, 0, VoteStart) or PixelGetColor(320, 60) = 0x00FF00) {
            ProcessLog("Game loaded")
            Sleep(1000)
            break
        }
        Reconnect()
    }
}

StartedGame() {
    loop {
        Sleep(1000)
        if (ok := FindText(&X, &Y, 349, 163, 455, 201, 0, 0, VoteStart) or PixelGetColor(320, 60) = 0x00FF00) {
            FixClick(x, y) ; click yes
            FixClick(x + 1, y + 1)
            FixClick(x - 2, y - 2)
            continue  ; Keep waiting if vote screen is still there
        }

        ; If we don't see vote screen anymore the game has started
        ProcessLog("Game Started")
        global stageStartTime := A_TickCount
        break
    }
}

StartSelectedMode() {
    ProcessLog("==> StartSelectedMode CALLED. Current Mode: " ModeDropdown.Text)
    if (mode = "Story") {
        StoryMode()
    } else if (mode = "Challenge") {
        ChallengeMode()
    } else if (mode = "Ranger") {
        RangerMode()
    } else if (mode = "ChallengeForRanger") {
        ChallengeForRangerMode()
    }
}

FormatStageTime(ms) {
    seconds := Floor(ms / 1000)
    minutes := Floor(seconds / 60)
    hours := Floor(minutes / 60)

    minutes := Mod(minutes, 60)
    seconds := Mod(seconds, 60)

    return Format("{:02}:{:02}:{:02}", hours, minutes, seconds)
}

ValidateMode() {
    if (ModeDropdown.Text = "") {
        ProcessLog("Choose mode, my Nigga")
        return false
    }
    if (!confirmClicked) {
        ProcessLog("Click on confirm, Nigga!")
        return false
    }
    return true
}

GetNavKeys() {
    return StrSplit(FileExist("Settings\UINavigation.txt") ? FileRead("Settings\UINavigation.txt", "UTF-8") : "\,#,}", ",")
}

StartMacro(*) {
    if (!ValidateMode()) {
        return
    }
    StartSelectedMode()
}

TogglePause(*) {
    Pause -1
    if (A_IsPaused) {
        ProcessLog("Macro Stopped")
        Sleep(1000)
    } else {
        ProcessLog("Continue Macro")
        Sleep(1000)
    }
}
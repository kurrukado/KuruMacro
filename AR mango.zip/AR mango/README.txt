Welcome to Anime Ranger Macro - made by Kuru

To make this Macro basically works included:

Main.ahk - where to run the macro
Function.ahk - a bridge between main file and GUI file
Image.ahk - store the image for searching up
GUI.ahk - for GUI and interact

Logs for debug
Findtext.ahk is developed function from ahk community, do not change it, use for macro searching

There's also libraries files for macro function

game flow: 
 - start macro
 - startselectedmode (challenege, ranger,...then for the movement)
 - restartstage (deteced map, check loaded and votestart), use for replaying game
 - monitorstage is playing game, monitorendscreen is when the game show up victory text
 - if returned back to lobby, turn back to startselectedmode


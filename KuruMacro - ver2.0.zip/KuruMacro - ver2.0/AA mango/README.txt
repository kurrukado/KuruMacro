Welcome to Anime Adventure Macro - made by Kuru

To make this Macro basically works included:

Main.ahk - where to run the macro
Function.ahk - a bridge between main file and GUI file
Image.ahk - store the image for searching up
GUI.ahk - for GUI and interact

There's also libraries files for macro function